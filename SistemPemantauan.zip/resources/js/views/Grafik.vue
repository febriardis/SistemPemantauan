<template>
    <div class="grafik">
        <h4 class="display-1">Grafik Pemantauan Air Akuarium</h4>
        <v-card class="eleveation-10">
            cek
            <!-- <chartjs-line :labels="labels" :data="dataset" :bind="true"> </chartjs-line> -->
        </v-card>
    </div>
</template>

<script>
export default {
    // data() {
    //     return {
    //         dataentry: null,
    //         datalabel: null,
    //         labels: ['January', 'February', 'March', 'April', 'May', 'June', 'July', 'August', 'September'            , 'October', 'November', 'December'],
    //         dataset: [5, 10, 15, 25, 45, 70, 115, 185, 70, 75, 70, 60]
    //     }
    // },
    // methods:{
    //     addData() {
    //         this.dataset.push(this.dataentry);
    //         this.labels.push(this.datalabel);
    //         this.datalabel = '';
    //         this.dataentry = '';
    //     }
    // }
}
</script>

